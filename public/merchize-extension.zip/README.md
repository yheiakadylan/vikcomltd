# POD Workflow - Merchize Fulfillment Extension

Tự động hóa quy trình fulfill đơn hàng từ POD Workflow sang Merchize.

## 🚀 Cài Đặt

### 1. Load Extension (Development Mode)

1. Mở Chrome và truy cập `chrome://extensions/`
2. Bật **Developer mode** (góc trên bên phải)
3. Click **Load unpacked**
4. Chọn thư mục `merchize-fulfillment-extension/`
5. Extension sẽ xuất hiện với icon POD

### 2. Xác Nhận Cài Đặt

- Mở POD Workflow web app
- Vào đơn hàng có status = "Done"
- Kiểm tra nút **"Fulfill to Merchize"** có hiển thị không

## 📖 Cách Sử Dụng

### Bước 1: Approve Design File
1. CS review design file
2. Bấm "Approve" → Đơn hàng chuyển sang status = "Done"

### Bước 2: Fulfill to Merchize
3. Bấm nút **"Fulfill to Merchize"**
4. Extension tự động:
   - Mở tab Merchize mới
   - Đăng nhập (nếu chưa login)
   - Tìm đơn hàng theo ReadableID hoặc SKU
   - Upload artwork lên Merchize
5. Nhận notification khi hoàn thành

## 🔧 Cấu Hình

### Selectors Merchize (Có thể cần điều chỉnh)

Nếu Merchize thay đổi giao diện, cập nhật selectors trong `content/merchize.js`:

```javascript
const CONFIG = {
  SELECTORS: {
    searchInput: 'input[type="search"]',
    orderRow: '[data-order-id], .order-item',
    uploadInput: 'input[type="file"][accept*="image"]',
    // ... thêm selectors khác
  }
};
```

### Timeouts

Điều chỉnh timeout nếu kết nối chậm:

```javascript
const CONFIG = {
  TIMEOUTS: {
    pageLoad: 3000,    // Thời gian chờ page load
    search: 2000,      // Thời gian chờ search results
    upload: 60000      // Thời gian chờ upload (60 giây)
  }
};
```

## 🛠️ Troubleshooting

### Extension không hoạt động

**Triệu chứng**: Nút "Fulfill to Merchize" không hiện

**Giải pháp**:
1. Kiểm tra extension đã được enable chưa
2. Refresh POD Workflow page (F5)
3. Xem Console (F12) → Có error nào không

### Không tìm thấy đơn hàng trên Merchize

**Triệu chứng**: Extension báo "Order not found"

**Giải pháp**:
1. Kiểm tra đơn hàng đã được tạo trên Merchize chưa
2. Đảm bảo ReadableID hoặc SKU khớp với Merchize
3. Thử tìm kiếm thủ công trên Merchize để xác nhận

### Upload artwork bị lỗi

**Triệu chứng**: Upload timeout hoặc failed

**Giải pháp**:
1. Kiểm tra kết nối internet
2. Đảm bảo file design không quá lớn (max 10MB)
3. Kiểm tra Firebase Storage URL có accessible không
4. Thử upload thủ công để test

### CORS Error

**Triệu chứng**: Console báo lỗi CORS

**Giải pháp**:
- Extension đã được config với `host_permissions` cho Firebase Storage
- Nếu vẫn lỗi, kiểm tra manifest.json có đủ permissions không

## 📊 Logs & Debugging

### View Extension Logs

1. Mở `chrome://extensions/`
2. Tìm "POD Merchize Fulfillment"
3. Click **"Service worker"** hoặc **"Inspect views: popup.html"**
4. Xem Console tab

### View Content Script Logs

1. Mở Merchize tab
2. Press F12 → Console tab
3. Tìm log với prefix `[Merchize Extension]`

## 🔒 Bảo Mật

### Dữ Liệu Được Lưu Trữ

Extension lưu tạm thời trong `chrome.storage.local`:
- Order ID
- ReadableID
- SKU
- Design File URLs

**Tự động xóa sau**: 1 giờ hoặc khi hoàn thành

### Không Lưu Trữ

- Passwords
- API Keys
- User credentials

### Permissions

Extension chỉ yêu cầu:
- `storage`: Lưu tạm dữ liệu fulfillment
- `tabs`: Mở tab Merchize
- `host_permissions`: Truy cập Merchize.com và Firebase Storage

## 🆕 Updates

Để update extension:

1. Pull code mới
2. Vào `chrome://extensions/`
3. Click **Reload** icon trên extension card

Hoặc tự động reload khi có thay đổi code (khi dev).

## 📞 Hỗ Trợ

Nếu gặp vấn đề:

1. **Check logs** (xem phần Logs & Debugging)
2. **Recreate issue** và note lại các bước
3. **Screenshot** error nếu có
4. **Liên hệ team** với thông tin trên

## 🎯 Features Tương Lai

- [ ] Batch fulfillment (nhiều đơn cùng lúc)
- [ ] Status sync từ Merchize về POD
- [ ] Auto-retry on failure
- [ ] Multiple provider support (Printway, etc.)
- [ ] Analytics dashboard

---

**Version**: 1.0.0  
**Last Updated**: 2026-01-19
