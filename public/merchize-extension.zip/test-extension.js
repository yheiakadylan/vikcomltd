/**
 * Extension Detection Test
 * Add this to browser console on POD Workflow app to test extension
 */

console.log('=== Extension Detection Test ===');

// 1. Check if flag is set
console.log('✓ Step 1: Checking window.podExtensionInstalled flag');
if (window.podExtensionInstalled) {
    console.log('✅ Extension flag detected! Value:', window.podExtensionInstalled);
} else {
    console.error('❌ Extension flag NOT detected!');
    console.log('Possible causes:');
    console.log('  - Extension not installed or not enabled');
    console.log('  - Content script not injected (check manifest.json matches)');
    console.log('  - Script timing issue (should run at document_idle)');
}

// 2. Test communication
console.log('\n✓ Step 2: Testing extension communication');

let responseReceived = false;

// Listen for response
window.addEventListener('POD_FULFILL_RESPONSE', (event) => {
    responseReceived = true;
    console.log('✅ Extension responded!', event.detail);
}, { once: true });

// Send test request
const testData = {
    id: 'test-123',
    readableId: 'TEST-001',
    title: 'Test Order',
    sku: 'TEST-SKU',
    designFiles: [
        {
            name: 'test.png',
            link: 'https://example.com/test.png',
            type: 'image'
        }
    ]
};

console.log('Sending test fulfill request...');
window.dispatchEvent(new CustomEvent('POD_FULFILL_REQUEST', {
    detail: { orderData: testData }
}));

// Check response after timeout
setTimeout(() => {
    if (responseReceived) {
        console.log('✅ Extension communication WORKING!');
    } else {
        console.error('❌ No response from extension after 2 seconds');
        console.log('Check:');
        console.log('  - Service worker is running (chrome://extensions/)');
        console.log('  - Background script has no errors');
        console.log('  - Content script is injected');
    }
}, 2000);

console.log('\n=== Test Running... (wait 2 seconds) ===');
