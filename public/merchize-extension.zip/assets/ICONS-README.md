# 🎨 Hướng Dẫn Tạo Extension Icons

## Cách 1: Sử Dụng Icon Generator (Recommended)

1. Mở file `icon-generator.html` trong Chrome browser
2. Icons sẽ tự động được generate và hiển thị
3. Click **"Download All Icons"** để tải cả 3 sizes
4. Chuyển các file vào folder `assets/`:
   - `icon-16.png` → `assets/icon-16.png`
   - `icon-48.png` → `assets/icon-48.png`  
   - `icon-128.png` → `assets/icon-128.png`

## Cách 2: Tự Tạo Icons

Nếu muốn custom design:

### Requirements:
- **Sizes**: 16x16, 48x48, 128x128 pixels
- **Format**: PNG with transparency
- **Design**: 
  - Purple gradient background (#667eea → #764ba2)
  - White icon/symbol in center
  - Simple, recognizable at small sizes

### Recommended Tools:
- Figma (free)
- Canva (free)
- Photoshop
- Illustrator

## Cách 3: Sử Dụng Online Tools

### Method A: Via Favicon Generator
1. Tạo icon 512x512px
2. Upload tới https://realfavicongenerator.net
3. Download và lấy sizes 16, 48, 128

### Method B: Via Canva
1. Tạo design 128x128px
2. Export PNG
3. Resize tới 48x48 và 16x16

## Icon Design Tips

✅ **DO:**
- Giữ design đơn giản
- Dùng màu tương phản cao
- Test ở size nhỏ nhất (16x16)
- Rounded corners cho professional look

❌ **DON'T:**
- Quá nhiều details ở icon nhỏ
- Text trong icon (không đọc được)
- Gradients phức tạp
- Transparent background (dùng solid color)

## Current Design

Icon hiện tại sử dụng:
- **Background**: Purple gradient (#667eea → #764ba2)
- **Symbol**: White rocket (symbolizing automation/speed)
- **Style**: Flat design, modern

## Testing Icons

Sau khi có icons:

1. Đặt vào folder `assets/`
2. Rebuild extension: `npm run build:extension`
3. Reload extension trong Chrome
4. Kiểm tra icon hiển thị đúng trong:
   - Extension list (chrome://extensions/)
   - Chrome toolbar
   - Extension popup

## Support

Nếu cần help chỉnh sửa icons, liên hệ team design hoặc sử dụng icon-generator.html tool có sẵn.
