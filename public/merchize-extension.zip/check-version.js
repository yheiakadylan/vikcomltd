/**
 * QUICK CHECK: Is Extension Using New Code?
 * Run this in webapp console
 */

console.log('%c=== EXTENSION CODE VERSION CHECK ===', 'color: blue; font-size: 16px; font-weight: bold');

// Check 1: Flag exists?
console.log('\n1️⃣ Checking window.podExtensionInstalled:');
console.log('   Value:', window.podExtensionInstalled);
console.log('   Expected: true');
console.log('   Status:', window.podExtensionInstalled === true ? '✅ PASS' : '❌ FAIL');

// Check 2: New code signature
console.log('\n2️⃣ Checking for NEW code signature...');
console.log('   Looking for log: "[POD Extension Bridge] Flag set:"');
console.log('   👆 Scroll up in console and look for this EXACT message');
console.log('   👉 If you see "[POD Extension Bridge] Loaded" instead → OLD CODE!');
console.log('   👉 If you see "[POD Extension Bridge] Loading..." → NEW CODE!');

// Visual separator
console.log('\n' + '='.repeat(50));
console.log('📋 DIAGNOSIS:');
console.log('='.repeat(50));

if (window.podExtensionInstalled === true) {
    console.log('✅ Flag is SET (Good!)');
    console.log('⚠️  But check console logs above:');
    console.log('   - NEW code says: "Loading..." then "Flag set:"');
    console.log('   - OLD code says: "Loaded" (inside IIFE)');
    console.log('');
    console.log('If you see OLD logs → Extension NOT reloaded properly');
    console.log('If you see NEW logs → Extension IS up to date!');
} else {
    console.log('❌ Flag is NOT SET');
    console.log('');
    console.log('Possible reasons:');
    console.log('1. Content script not injected (manifest issue)');
    console.log('2. Wrong URL pattern in manifest');
    console.log('3. Extension disabled');
    console.log('');
    console.log('Next steps:');
    console.log('• Check chrome://extensions/ → Extension is enabled');
    console.log('• Check manifest.json matches localhost URL');
    console.log('• Try removing and re-loading extension');
}

console.log('\n' + '='.repeat(50));
console.log('🔧 QUICK FIX STEPS:');
console.log('='.repeat(50));
console.log('1. Go to: chrome://extensions/');
console.log('2. Find: POD Workflow - Merchize Fulfillment');
console.log('3. Click: 🔄 Reload button');
console.log('4. Come back here');
console.log('5. Press: Ctrl + Shift + R (hard reload)');
console.log('6. Run this script again');
console.log('='.repeat(50));
