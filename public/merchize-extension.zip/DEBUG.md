# Extension Debug Guide

## ✅ Fixes Applied

### Problem:
```
Service worker registration failed. Status code: 15
Uncaught TypeError: Cannot read properties of undefined (reading 'create')
```

### Root Causes:
1. **Missing "alarms" permission** → `chrome.alarms.create()` failed
2. **Unnecessary "type: module"** → Service worker registration error
3. **Content script timing issue** → `podExtensionInstalled` flag not set when webapp checks

### Solutions Applied:

#### 1. Added "alarms" permission to `manifest.json`:
```json
"permissions": [
    "storage",
    "tabs",
    "scripting",
    "activeTab",
    "notifications",
    "alarms"  ← Added
]
```

#### 2. Removed `"type": "module"` from background config:
```json
"background": {
    "service_worker": "background/background.js"
    // Removed: "type": "module"
}
```

**Reason**: `background.js` doesn't use ES modules (no import/export), so `type: module` causes registration failures.

#### 3. Fixed content script timing in `manifest.json`:
```json
// pod-bridge.js content script
"run_at": "document_idle"  // Changed from "document_start"
```

**Reason**: Running at `document_start` was too early - webapp hadn't loaded yet, so `podExtensionInstalled` flag wasn't visible when FulfillModal checked it. This caused the app to always redirect to extension install page.

---

## 🧪 Testing Steps

### 1. Reload Extension in Chrome:
1. Open `chrome://extensions/`
2. Click **🔄 Reload** on "POD Workflow - Merchize Fulfillment"
3. Check for errors in **Errors** section

### 2. Test Service Worker:
1. Click **"Service Worker"** link on extension card
2. Console should show: `[Background] POD Fulfillment Extension initialized`
3. No errors should appear

### 3. Test Fulfill Flow:
1. Open POD Workflow dashboard
2. Click **"Fulfill to Merchize"** on a done task
3. Extension should open Merchize tab
4. Check background console logs

---

## 🐛 Still Getting Errors?

### Check Service Worker Console:
```
chrome://extensions/ → POD Workflow → Service Worker → Inspect
```

### Common Issues:

#### Error: "chrome.xxx is undefined"
→ Add missing permission to `manifest.json` permissions array

#### Error: "Failed to load script"
→ Check file paths in `manifest.json` match actual files

#### Error: "Invalid manifest"
→ Validate JSON syntax at jsonlint.com

---

## 📂 Extension Structure

```
merchize-fulfillment-extension/
├── manifest.json           ← Main config
├── background/
│   └── background.js       ← Service worker (no ES modules)
├── content/
│   ├── merchize.js         ← Inject into seller.merchize.com
│   └── pod-bridge.js       ← Bridge to POD app
├── popup/
│   ├── popup.html
│   ├── popup.js
│   └── popup.css
└── assets/
    ├── icon-16.png
    ├── icon-48.png
    └── icon-128.png
```

---

## 🔄 Rebuild Extension

After any changes to extension files:

```bash
node scripts/build-extension.js
```

This creates `/public/merchize-extension.zip` ready for distribution.

---

## ✅ Checklist

- [x] Added "alarms" permission
- [x] Removed "type: module" from background
- [x] All icons present (16, 48, 128)
- [x] background.js has no syntax errors
- [x] manifest.json is valid JSON
- [ ] Extension loads without errors
- [ ] Service worker initializes
- [ ] Fulfill flow works end-to-end
